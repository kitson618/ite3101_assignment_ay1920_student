============================= test session starts ==============================
platform linux -- Python 3.6.1, pytest-3.7.3, py-1.5.4, pluggy-0.7.1
rootdir: /tmp/ite3101_introduction_to_programming/tests/lab03, inifile:
collected 1 item

../../tmp/ite3101_introduction_to_programming/tests/lab03/test_ch03_t04_hot_date.py F [100%]

=================================== FAILURES ===================================
_______________________________ TestOutput.test ________________________________

self = <tests.lab03.test_ch03_t04_hot_date.TestOutput testMethod=test>

    def test(self):
        temp_globals, temp_locals, content, output = execfile("lab03/ch03_t04_hot_date.py")
        print(temp_locals)
    
        now = temp_locals['now']
    
        expected = '%02d/%02d/%04d' % (now.month, now.day, now.year) + "\n"
        self.assertIsNotNone(temp_locals['now'])
>       self.assertEqual(expected, output)
E       AssertionError: '10/02/2018\n' != '10-02-2018\n'
E       - 10/02/2018
E       ?   ^  ^
E       + 10-02-2018
E       ?   ^  ^

/tmp/ite3101_introduction_to_programming/tests/lab03/test_ch03_t04_hot_date.py:15: AssertionError
----------------------------- Captured stdout call -----------------------------
{'datetime': <class 'datetime.datetime'>, 'now': datetime.datetime(2018, 10, 2, 6, 58, 36, 637761)}
=========================== 1 failed in 0.20 seconds ===========================
