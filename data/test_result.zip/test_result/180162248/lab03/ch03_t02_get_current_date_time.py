============================= test session starts ==============================
platform linux -- Python 3.6.1, pytest-3.7.3, py-1.5.4, pluggy-0.7.1
rootdir: /tmp/ite3101_introduction_to_programming/tests/lab03, inifile:
collected 2 items

../../tmp/ite3101_introduction_to_programming/tests/lab03/test_ch03_t02_get_current_date_time.py . [ 50%]
F                                                                        [100%]

=================================== FAILURES ===================================
____________________________ TestOutput.test_output ____________________________

self = <tests.lab03.test_ch03_t02_get_current_date_time.TestOutput testMethod=test_output>

    def test_output(self):
        result = get_script_output("lab03/ch03_t02_get_current_date_time.py")
>       self.assertEqual(27, len(result))
E       AssertionError: 27 != 0

/tmp/ite3101_introduction_to_programming/tests/lab03/test_ch03_t02_get_current_date_time.py:14: AssertionError
----------------------------- Captured stdout call -----------------------------
Testing file:  /tmp/ite3101_introduction_to_programming/tests/../lab/lab03/ch03_t02_get_current_date_time.py
====================== 1 failed, 1 passed in 0.22 seconds ======================
