============================= test session starts ==============================
platform linux -- Python 3.6.1, pytest-3.7.3, py-1.5.4, pluggy-0.7.1
rootdir: /tmp/ite3101_introduction_to_programming/tests/lab01, inifile:
collected 1 item

../../tmp/ite3101_introduction_to_programming/tests/lab01/test_ch01_t06_arithmetic.py F [100%]

=================================== FAILURES ===================================
_______________________________ TestOutput.test ________________________________

self = <tests.lab01.test_ch01_t06_arithmetic.TestOutput testMethod=test>

    def test(self):
        temp_globals, temp_locals, content, output = execfile("lab01/ch01_t06_arithmetic.py")
        print(temp_locals)
>       self.assertIsInstance(temp_locals['product'], int)
E       KeyError: 'product'

/tmp/ite3101_introduction_to_programming/tests/lab01/test_ch01_t06_arithmetic.py:10: KeyError
----------------------------- Captured stdout call -----------------------------
{'prodct': 2, 'remainder': 1}
=========================== 1 failed in 0.16 seconds ===========================
