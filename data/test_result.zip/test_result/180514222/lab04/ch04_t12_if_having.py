============================= test session starts ==============================
platform linux -- Python 3.6.1, pytest-3.7.3, py-1.5.4, pluggy-0.7.1
rootdir: /tmp/ite3101_introduction_to_programming/tests/lab04, inifile:
collected 1 item

../../tmp/ite3101_introduction_to_programming/tests/lab04/test_ch04_t12_if_having.py F [100%]

=================================== FAILURES ===================================
_______________________________ TestOutput.test ________________________________

self = <tests.lab04.test_ch04_t12_if_having.TestOutput testMethod=test>

    def test(self):
>       temp_globals, temp_locals, content, output = execfile("lab04/ch04_t12_if_having.py")

/tmp/ite3101_introduction_to_programming/tests/lab04/test_ch04_t12_if_having.py:8: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
/tmp/ite3101_introduction_to_programming/tests/console_test_helper.py:74: in execfile
    exec(compile(content, test_file_path_name, 'exec'), temp_globals, temp_locals)
/tmp/ite3101_introduction_to_programming/lab/lab04/ch04_t12_if_having.py:11: in <module>
    print(using_control_once())
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

    def using_control_once() -> str:
>       if true:
E       NameError: name 'true' is not defined

/tmp/ite3101_introduction_to_programming/lab/lab04/ch04_t12_if_having.py:2: NameError
=========================== 1 failed in 0.21 seconds ===========================
