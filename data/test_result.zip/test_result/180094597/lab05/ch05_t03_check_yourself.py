============================= test session starts ==============================
platform linux -- Python 3.6.1, pytest-3.7.3, py-1.5.4, pluggy-0.7.1
rootdir: /tmp/ite3101_introduction_to_programming/tests/lab05, inifile:
collected 2 items

../../tmp/ite3101_introduction_to_programming/tests/lab05/test_ch05_t03_check_yourself.py . [ 50%]
F                                                                        [100%]

=================================== FAILURES ===================================
__________________________ TestOutput.test_word_input __________________________

self = <tests.lab05.test_ch05_t03_check_yourself.TestOutput testMethod=test_word_input>

    def test_word_input(self):
        user_input = ["Cyrus"]
        with patch('builtins.input', side_effect=user_input):
            temp_globals, temp_locals, content, output = execfile("lab05/ch05_t03_check_yourself.py")
    
>       self.assertEqual("Welcome to the Pig Latin Translator!\nCyrus\n", output)
E       AssertionError: 'Welcome to the Pig Latin Translator!\nCyrus\n' != 'Welcome to the Pig Latin Translator!\nDude type something\n'
E         Welcome to the Pig Latin Translator!
E       - Cyrus
E       + Dude type something

/tmp/ite3101_introduction_to_programming/tests/lab05/test_ch05_t03_check_yourself.py:14: AssertionError
====================== 1 failed, 1 passed in 0.16 seconds ======================
