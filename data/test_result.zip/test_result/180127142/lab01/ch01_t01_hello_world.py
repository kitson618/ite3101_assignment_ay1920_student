============================= test session starts ==============================
platform linux -- Python 3.6.1, pytest-3.7.3, py-1.5.4, pluggy-0.7.1
rootdir: /tmp/ite3101_introduction_to_programming/tests/lab01, inifile:
collected 1 item

../../tmp/ite3101_introduction_to_programming/tests/lab01/test_ch01_t01_hello_world.py F [100%]

=================================== FAILURES ===================================
_______________________________ TestOutput.test ________________________________

self = <tests.lab01.test_ch01_t01_hello_world.TestOutput testMethod=test>

    def test(self):
        result = get_script_output("lab01/ch01_t01_hello_world.py")
>       self.assertEqual("Hello, world!\n", result)
E       AssertionError: 'Hello, world!\n' != ''
E       - Hello, world!

/tmp/ite3101_introduction_to_programming/tests/lab01/test_ch01_t01_hello_world.py:10: AssertionError
----------------------------- Captured stdout call -----------------------------
Testing file:  /tmp/ite3101_introduction_to_programming/tests/../lab/lab01/ch01_t01_hello_world.py
=========================== 1 failed in 0.44 seconds ===========================
