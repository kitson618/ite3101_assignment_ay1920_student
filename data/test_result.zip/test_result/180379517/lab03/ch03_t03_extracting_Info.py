============================= test session starts ==============================
platform linux -- Python 3.6.1, pytest-3.7.3, py-1.5.4, pluggy-0.7.1
rootdir: /tmp/ite3101_introduction_to_programming/tests/lab03, inifile:
collected 1 item

../../tmp/ite3101_introduction_to_programming/tests/lab03/test_ch03_t03_extracting_Info.py F [100%]

=================================== FAILURES ===================================
_______________________________ TestOutput.test ________________________________

self = <tests.lab03.test_ch03_t03_extracting_Info.TestOutput testMethod=test>

    def test(self):
        temp_globals, temp_locals, content, output = execfile("lab03/ch03_t03_extracting_Info.py")
        print(temp_locals)
    
        now = temp_locals['now']
    
        expected = str(now) + "\n" + \
                   str(now.year) + "\n" + \
                   str(now.month) + "\n" + \
                   str(now.day) + "\n"
    
        self.assertIsNotNone(temp_locals['now'])
>       self.assertEqual(expected, output)
E       AssertionError: '2018-09-18 07:25:37.121383\n2018\n9\n18\n' != '2018-09-18 07:25:37.121383\n2018\n9\n'
E         2018-09-18 07:25:37.121383
E         2018
E         9
E       - 18

/tmp/ite3101_introduction_to_programming/tests/lab03/test_ch03_t03_extracting_Info.py:19: AssertionError
----------------------------- Captured stdout call -----------------------------
{'datetime': <class 'datetime.datetime'>, 'now': datetime.datetime(2018, 9, 18, 7, 25, 37, 121383)}
=========================== 1 failed in 0.36 seconds ===========================
