============================= test session starts ==============================
platform linux -- Python 3.6.1, pytest-3.7.3, py-1.5.4, pluggy-0.7.1
rootdir: /tmp/ite3101_introduction_to_programming/tests/lab04, inifile:
collected 1 item

../../tmp/ite3101_introduction_to_programming/tests/lab04/test_ch04_t14_elif.py F [100%]

=================================== FAILURES ===================================
_______________________________ TestOutput.test ________________________________

self = <tests.lab04.test_ch04_t14_elif.TestOutput testMethod=test>

    def test(self):
        temp_globals, temp_locals, content, output = execfile("lab04/ch04_t14_elif.py")
    
        expected = """-1
    0
    1
    """
>       self.assertEqual(expected, output)
E       AssertionError: '-1\n0\n1\n' != '0\n0\n0\n'
E       - -1
E         0
E       - 1
E       + 0
E       + 0

/tmp/ite3101_introduction_to_programming/tests/lab04/test_ch04_t14_elif.py:14: AssertionError
=========================== 1 failed in 0.20 seconds ===========================
