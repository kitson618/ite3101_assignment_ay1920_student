============================= test session starts ==============================
platform linux -- Python 3.6.1, pytest-3.7.3, py-1.5.4, pluggy-0.7.1
rootdir: /tmp/ite3101_introduction_to_programming/tests/lab01, inifile:
collected 1 item

../../tmp/ite3101_introduction_to_programming/tests/lab01/test_ch01_t09_numbers.py F [100%]

=================================== FAILURES ===================================
_______________________________ TestOutput.test ________________________________

self = <tests.lab01.test_ch01_t09_numbers.TestOutput testMethod=test>

    def test(self):
>       temp_globals, temp_locals, content, output = execfile("lab01/ch01_t09_numbers.py")

/tmp/ite3101_introduction_to_programming/tests/lab01/test_ch01_t09_numbers.py:8: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
/tmp/ite3101_introduction_to_programming/tests/console_test_helper.py:74: in execfile
    exec(compile(content, test_file_path_name, 'exec'), temp_globals, temp_locals)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

    cucumbers=1
    pricee_per_cucumber=3.25
>   total_cost=cucumbers*price_per_cucumber
E   NameError: name 'price_per_cucumber' is not defined

/tmp/ite3101_introduction_to_programming/lab/lab01/ch01_t09_numbers.py:3: NameError
=========================== 1 failed in 0.16 seconds ===========================
