============================= test session starts ==============================
platform linux -- Python 3.6.1, pytest-3.7.3, py-1.5.4, pluggy-0.7.1
rootdir: /tmp/ite3101_introduction_to_programming/tests/lab05, inifile:
collected 3 items

../../tmp/ite3101_introduction_to_programming/tests/lab05/test_ch05_t07_word_up.py F [ 33%]
FF                                                                       [100%]

=================================== FAILURES ===================================
_________________________ TestOutput.test_empty_input __________________________

self = <tests.lab05.test_ch05_t07_word_up.TestOutput testMethod=test_empty_input>

    def test_empty_input(self):
        user_input = [""]
        with patch('builtins.input', side_effect=user_input):
>           temp_globals, temp_locals, content, output = execfile("lab05/ch05_t07_word_up.py")

/tmp/ite3101_introduction_to_programming/tests/lab05/test_ch05_t07_word_up.py:27: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

file_relative_path = 'lab05/ch05_t07_word_up.py'
temp_globals = {'__file__': '/tmp/ite3101_introduction_to_programming/tests/../lab/lab05/ch05_t07_word_up.py', '__name__': '__main__'}
temp_locals = {}

    def execfile(file_relative_path: str, temp_globals: dict = None, temp_locals: dict = None) -> \
            Tuple[Union[Dict[str, str], dict], Union[dict, dict], str, str]:
        test_file_path_name = get_path_name(file_relative_path)
        if temp_globals is None:
            temp_globals = {}
        temp_globals.update({
            "__file__": test_file_path_name,
            "__name__": "__main__",
        })
    
        if temp_locals is None:
            temp_locals = {}
        content = ""
        with stdout_io() as s:
            try:
                with open(test_file_path_name, 'rb') as file:
                    content = file.read()
>                   exec(compile(content, test_file_path_name, 'exec'), temp_globals, temp_locals)
E                     File "/tmp/ite3101_introduction_to_programming/tests/../lab/lab05/ch05_t07_word_up.py", line 8
E                       print(original)
E                                     ^
E                   IndentationError: unindent does not match any outer indentation level

/tmp/ite3101_introduction_to_programming/tests/console_test_helper.py:74: IndentationError
______________________ TestOutput.test_invalid_word_input ______________________

self = <tests.lab05.test_ch05_t07_word_up.TestOutput testMethod=test_invalid_word_input>

    def test_invalid_word_input(self):
        user_input = ["Cyrus!"]
        with patch('builtins.input', side_effect=user_input):
>           temp_globals, temp_locals, content, output = execfile("lab05/ch05_t07_word_up.py")

/tmp/ite3101_introduction_to_programming/tests/lab05/test_ch05_t07_word_up.py:20: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

file_relative_path = 'lab05/ch05_t07_word_up.py'
temp_globals = {'__file__': '/tmp/ite3101_introduction_to_programming/tests/../lab/lab05/ch05_t07_word_up.py', '__name__': '__main__'}
temp_locals = {}

    def execfile(file_relative_path: str, temp_globals: dict = None, temp_locals: dict = None) -> \
            Tuple[Union[Dict[str, str], dict], Union[dict, dict], str, str]:
        test_file_path_name = get_path_name(file_relative_path)
        if temp_globals is None:
            temp_globals = {}
        temp_globals.update({
            "__file__": test_file_path_name,
            "__name__": "__main__",
        })
    
        if temp_locals is None:
            temp_locals = {}
        content = ""
        with stdout_io() as s:
            try:
                with open(test_file_path_name, 'rb') as file:
                    content = file.read()
>                   exec(compile(content, test_file_path_name, 'exec'), temp_globals, temp_locals)
E                     File "/tmp/ite3101_introduction_to_programming/tests/../lab/lab05/ch05_t07_word_up.py", line 8
E                       print(original)
E                                     ^
E                   IndentationError: unindent does not match any outer indentation level

/tmp/ite3101_introduction_to_programming/tests/console_test_helper.py:74: IndentationError
__________________________ TestOutput.test_word_input __________________________

self = <tests.lab05.test_ch05_t07_word_up.TestOutput testMethod=test_word_input>

    def test_word_input(self):
        user_input = ["Cyrus"]
        with patch('builtins.input', side_effect=user_input):
>           temp_globals, temp_locals, content, output = execfile("lab05/ch05_t07_word_up.py")

/tmp/ite3101_introduction_to_programming/tests/lab05/test_ch05_t07_word_up.py:12: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

file_relative_path = 'lab05/ch05_t07_word_up.py'
temp_globals = {'__file__': '/tmp/ite3101_introduction_to_programming/tests/../lab/lab05/ch05_t07_word_up.py', '__name__': '__main__'}
temp_locals = {}

    def execfile(file_relative_path: str, temp_globals: dict = None, temp_locals: dict = None) -> \
            Tuple[Union[Dict[str, str], dict], Union[dict, dict], str, str]:
        test_file_path_name = get_path_name(file_relative_path)
        if temp_globals is None:
            temp_globals = {}
        temp_globals.update({
            "__file__": test_file_path_name,
            "__name__": "__main__",
        })
    
        if temp_locals is None:
            temp_locals = {}
        content = ""
        with stdout_io() as s:
            try:
                with open(test_file_path_name, 'rb') as file:
                    content = file.read()
>                   exec(compile(content, test_file_path_name, 'exec'), temp_globals, temp_locals)
E                     File "/tmp/ite3101_introduction_to_programming/tests/../lab/lab05/ch05_t07_word_up.py", line 8
E                       print(original)
E                                     ^
E                   IndentationError: unindent does not match any outer indentation level

/tmp/ite3101_introduction_to_programming/tests/console_test_helper.py:74: IndentationError
=========================== 3 failed in 0.28 seconds ===========================
