============================= test session starts ==============================
platform linux -- Python 3.6.1, pytest-3.7.3, py-1.5.4, pluggy-0.7.1
rootdir: /tmp/ite3101_introduction_to_programming/tests/lab05, inifile:
collected 3 items

../../tmp/ite3101_introduction_to_programming/tests/lab05/test_ch05_t10_test.py . [ 33%]
..                                                                       [100%]

=========================== 3 passed in 0.12 seconds ===========================
